easybuffer.vim
==============

easybuffer.vim - is a simple plugin to quickly switch between buffers using corresponding
keys or buffer numbers displayed in easybuffer quick switch window  

screenshot
----------
![image](http://imgur.com/qYSaW.png)

usage
-----

    :EasyBuffer
